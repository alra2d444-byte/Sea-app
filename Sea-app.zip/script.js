function generate() {
  const idea = document.getElementById("idea").value;
  const output = document.getElementById("output");

  if (!idea.trim()) {
    output.innerHTML = "<p style='color:red'>Please enter an idea!</p>";
    return;
  }

  // placeholder (تقدر تربطه بالذكاء الاصطناعي لاحقاً)
  output.innerHTML = `<p>✨ Generating video & image for: <b>${idea}</b> ...</p>`;
}